
package NeuralNet;

public class FaivaAI {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Net net = new Net();
        net.CreaterNet(new int[]{2,3,2});
        net.createData();
        net.run();
      
    }
    
}
