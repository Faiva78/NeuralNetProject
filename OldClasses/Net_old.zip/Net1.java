/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package NeuralNet;

import java.util.List;
import java.util.ArrayList;

/**
 *
 * @author Teso Nicola
 */
public class Net1 {

    private List<Neurone> NeuronList = new ArrayList();
    private List<Assone> AssonList = new ArrayList<>();
    private List<Assone> inputList = new ArrayList<>();
    private List<Assone> outputList = new ArrayList<>();

    /**
     * List of neuron layers
     */
    public ArrayList<ArrayList<Neurone>> Layers = new ArrayList<ArrayList<Neurone>>();
    /**
     * Data structure for inputs,output and errors
     */
    public NetData dataSet = new NetData();

    /*create input and output axon */
    private void addInOut() {
        ArrayList<Neurone> inp = Layers.get(0);;
        ArrayList<Neurone> out = Layers.get(Layers.size() - 1);
        for (int i = 0; i < inp.size(); i++) {
            Neurone neuron = inp.get(i);
            Assone newAsson = new Assone();
            newAsson.weight = 1;
            newAsson.toNeuron = neuron;
            inputList.add(newAsson);
            AssonList.add(newAsson);
        }
        for (int i = 0; i < out.size(); i++) {
            Neurone neuron = out.get(i);
            Assone newAsson = new Assone();
            newAsson.weight = 1;
            newAsson.fromNeuron = neuron;
            outputList.add(newAsson);
            AssonList.add(newAsson);
        }
    }

    private void addAxons() {
        for (int i = 1; i < Layers.size(); i++) {
            ArrayList<Neurone> layer = Layers.get(i);
            ArrayList<Neurone> layerPrec = Layers.get(i - 1);
            for (int j = 0; j < layerPrec.size(); j++) {
                Neurone neuronPrec = layerPrec.get(j);
                for (int k = 0; k < layer.size(); k++) {
                    Neurone neuronThis = layer.get(k);
                    Assone NewAss = new Assone();
                    NewAss.fromNeuron = neuronPrec;
                    NewAss.toNeuron = neuronThis;
                    AssonList.add(NewAss);
                }
            }
        }
    }

    private void addNeurons(int topology[]) {

        for (int i = 0; i < topology.length; i++) {
            int N = topology[i];
            ArrayList<Neurone> layer = new ArrayList<Neurone>();
            for (int j = 0; j < N; j++) {
                Neurone neuron = new Neurone();
                NeuronList.add(neuron);
                layer.add(neuron);
            }
            Layers.add(layer);
        }
    }

    /**
     * Create a neural net with supplied topology
     *
     * @param topology Array of Int with the description of the net topology eg.
     * {1,3,2} <br>
     * - The first element is the input neurons number <br>
     * - The last element is the output neurons number <br>
     * - The elements in between are the layers neuron number <br>
     */
    public void CreaterNet(int topology[]) {
        addNeurons(topology);
        addAxons();
        addInOut();

    }

    public void createData() {

        dataSet.addInputData(new double[]{0, 0}, new double[]{0, 1});
        dataSet.addInputData(new double[]{1, 0}, new double[]{1, 0});
        dataSet.addInputData(new double[]{0, 1}, new double[]{1, 0});
        dataSet.addInputData(new double[]{1, 1}, new double[]{0, 1});

    }

    /**
     * Run a net batch and update the dataset <br>
     * <p>
     * This method :<br>
     * - Update the axon input values with the net dataset <br>
     * - Evaluate the net <br>
     * - Calculate errors, add partial MSE and update dataset  <br>
     * - Calculate output MSE and net MSE and update dataset <br>
     */
    public void run() {
        // for as many as  data elements
        for (int i = 0; i < dataSet.size(); i++) {

            // for as many as net inputs 
            for (int j = 0; j < inputList.size(); j++) {                                         //for (int j = 0; j < netData.InputData.get(i).length; j++) {
                // add the data from dataset inputs to input axons values
                inputList.get(j).value = dataSet.InputData.get(i)[j];
            }

            // evaluate the net
            evaluateNet();

            // for as many as net outputs
            for (int j = 0; j < outputList.size(); j++) {

                // retrieve and add axon output to dataset
                double result = outputList.get(j).value;
                dataSet.resultData.get(i)[j] = result;

                // retrieve the expected output from dataset
                double Indata = dataSet.TestData.get(i)[j];

                // add expected output and the result to MSE partial sum (Y'-Y)
                dataSet.costsFunctions.get(i).add(Indata, result);

                // calcluate error and add it to dataset
                dataSet.errorsData.get(i)[j] = Func.meanError(Indata, result);
                // TODO test fow working!!
                //data.errorsData.get(i)[j] = data.MSE_sum.get(i).error; 
            }
        }

        // for as many as  data elements
        for (int i = 0; i < dataSet.size(); i++) {

            // evaluate and retrieve the total MSE of current data element 
            double mean = dataSet.costsFunctions.get(i).evaluate();
            // update the dataset  total MSE
            dataSet.costData.set(i, mean);

            // update the net total MCE
            dataSet.TotalMSE = dataSet.TotalMSE + mean;
        }
    }

    // evaluate the net with the dataset
    private void evaluateNet() {

        // for as many layers in net
        for (int q = 0; q < Layers.size(); q++) {
            ArrayList<Neurone> layerList = Layers.get(q);

            // for every neuron in the layer
            for (int w = 0; w < layerList.size(); w++) {
                Neurone neuron = layerList.get(w);

                // find it's axons inputs 
                List<Assone> axonInputs = FindInputs(neuron);

                int numInputs = axonInputs.size(); //input axons number
                double weightedSum = 0; //weighted sum variable

                // for as many as input axons (calculate the weight sum function
                for (int y = 0; y < numInputs; y++) {

                    //retrieve the  axon
                    Assone axon = axonInputs.get(y);

                    //multiplicate the neuron output value with the axon weight
                    double axonValueWeighted = (axon.getFromNeuronValue() * axon.weight);

                    // sum over the partials 
                    weightedSum = weightedSum + axonValueWeighted;
                }

                //calculate the neuron utput function with the summed weights
                double Average = weightedSum / numInputs; //divide the total sum by input number
                double out = Average + neuron.bias; // add a bias
                double value = neuron.sigmoid.evaluate(out); // evaluate the neuron function
                neuron.value = value; // update the neuron value                        //Uti.printNetElement(neuron); //DEBUG

                //find it's axon outputs
                List<Assone> output = FindOutputs(neuron);

                // for as many as output axons
                for (int z = 0; z < output.size(); z++) {
                    Assone outAsson = output.get(z);
                    
                    // update axon value with neuron value
                    outAsson.value = neuron.value;

                    // Uti.printNetElement(outAsson); // DEBUG
                }
            }
        }
    }

    private List FindOutputs(Neurone neur) {
        List<Assone> returnList = new ArrayList<>();
        for (int Idx = 0; Idx < AssonList.size(); Idx++) {
            Assone get = AssonList.get(Idx);
            if (get.fromNeuron != null) {
                if (get.fromNeuron.equals(neur)) {
                    returnList.add(get);
                }
            }
        }
        return returnList;
    }

    private List FindInputs(Neurone neur) {
        List<Assone> returnList = new ArrayList<>();
        for (int Idx = 0; Idx < AssonList.size(); Idx++) {
            Assone get = AssonList.get(Idx);
            if (get.toNeuron != null) {
                if (get.toNeuron.equals(neur)) {
                    returnList.add(get);
                }
            }
        }
        return returnList;
    }

}
