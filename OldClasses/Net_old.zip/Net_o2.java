/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package NeuralNet;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author alessia
 */
public class Net_o2 {
    
    private List<Neurone> NeuronList = new ArrayList();
    private List<Assone> AssonList = new ArrayList<>();
    public List<Assone> inputList = new ArrayList<>();
    public List<Assone> outputList = new ArrayList<>();
    public ArrayList<ArrayList<Neurone>> Layers = new ArrayList<ArrayList<Neurone>>();
    public ArrayList<double[]> DataList = new ArrayList<double[]>();
    public ArrayList<double[]> DataOut = new ArrayList<double[]>();
    public NetData data = new NetData();

    private void addInOut() {
        ArrayList<Neurone> inp = Layers.get(0);;
        ArrayList<Neurone> out = Layers.get(Layers.size() - 1);
        for (int i = 0; i < inp.size(); i++) {
            Neurone neuron = inp.get(i);
            Assone newAsson = new Assone();
            newAsson.weight = 1;
            newAsson.toNeuron = neuron;
            inputList.add(newAsson);
            AssonList.add(newAsson);
        }
        for (int i = 0; i < out.size(); i++) {
            Neurone neuron = out.get(i);
            Assone newAsson = new Assone();
            newAsson.weight = 1;
            newAsson.fromNeuron = neuron;
            outputList.add(newAsson);
            AssonList.add(newAsson);
        }
    }

    private void addAxons() {
        for (int i = 1; i < Layers.size(); i++) {
            ArrayList<Neurone> layer = Layers.get(i);
            ArrayList<Neurone> layerPrec = Layers.get(i - 1);
            for (int j = 0; j < layerPrec.size(); j++) {
                Neurone neuronPrec = layerPrec.get(j);
                for (int k = 0; k < layer.size(); k++) {
                    Neurone neuronThis = layer.get(k);
                    Assone NewAss = new Assone();
                    NewAss.fromNeuron = neuronPrec;
                    NewAss.toNeuron = neuronThis;
                    AssonList.add(NewAss);
                }
            }
        }
    }

    private void addNeurons(int topology[]) {

        for (int i = 0; i < topology.length; i++) {
            int N = topology[i];
            ArrayList<Neurone> layer = new ArrayList<Neurone>();
            for (int j = 0; j < N; j++) {
                Neurone neuron = new Neurone();
                NeuronList.add(neuron);
                layer.add(neuron);
            }
            Layers.add(layer);
        }
    }

    public void CreateLayerNet(int topology[]) {
        addNeurons(topology);
        addAxons();
        addInOut();
    }

    public void createData() {
        double t1[] = {0, 0, 0};
        double t2[] = {1, 0, 1};
        double t3[] = {0, 1, 1};
        double t4[] = {1, 1, 0};
        //ArrayList<double[]> DataList=new ArrayList<double[]>();
        DataList.add(t1);
        DataList.add(t2);
        DataList.add(t3);
        DataList.add(t4);

        data.addInputData(new double[]{0, 0}, new double[]{0, 1});
        data.addInputData(new double[]{1, 0}, new double[]{1, 0});
        data.addInputData(new double[]{0, 1}, new double[]{1, 0});
        data.addInputData(new double[]{1, 1}, new double[]{0, 1});

    }

    public void run() {
        for (int i = 0; i < data.size(); i++) {

            // add the data from dataset to axons
            for (int j = 0; j < data.InputData.get(i).length; j++) {
                inputList.get(j).value = data.InputData.get(i)[j];
            }

            // evaluate
            evaluate();

            for (int j = 0; j < outputList.size(); j++) {
                // add axon output to dataset
                double result = outputList.get(j).value;
                data.resultData.get(i)[j] = result;

                // add to MSE the data  and calculate error
                double Indata = data.TestData.get(i)[j];
                data.costsFunctions.get(i).add(Indata, result);

                //data.errorsData.get(i)[j] = data.MSE_sum.get(i).error;
                data.errorsData.get(i)[j] = Func.meanError(Indata, result);
            }
        }

        // rerun all dataset list
        for (int i = 0; i < data.size(); i++) {
            // calculate MSE and add it to the result MSE
            double mean = data.costsFunctions.get(i).evaluate();
            data.costData.set(i, mean);
            // sum for all MSE
            data.TotalMSE = data.TotalMSE + mean;
        }

    }
    
    
    

    
    
    private void evaluate() {

        for (int x = 0; x < NeuronList.size(); x++) {
            Neurone neuron = NeuronList.get(x);// for every N calculate it's outputs value
            List<Assone> axInputs = FindInputs(neuron);
            int numInputs = axInputs.size();
            double sum = 0; //weighted sum
            for (int y = 0; y < numInputs; y++) { // for every input value
                Assone asson = axInputs.get(y);
                double partial = (asson.getFromNeuronValue() * asson.weight);
                sum = sum + partial;
            }
            double summ = sum / numInputs;
            double out = summ + neuron.bias;
            double value = neuron.sigmoid.evaluate(out);
            neuron.value = value;
            //Uti.printNetElement(neuron);

            //  update the R value equals ro N value
            List<Assone> output = FindOutputs(neuron);
            for (int z = 0; z < output.size(); z++) {
                Assone outAsson = output.get(z);
                outAsson.value = neuron.value;
                // Uti.printNetElement(outAsson);
            }
        }
    }
    
    private List FindOutputs(Neurone neur) {
        List<Assone> returnList = new ArrayList<>();
        for (int Idx = 0; Idx < AssonList.size(); Idx++) {
            Assone get = AssonList.get(Idx);
            if (get.fromNeuron != null) {
                if (get.fromNeuron.equals(neur)) {
                    returnList.add(get);
                }
            }
        }
        return returnList;
    }

    private List FindInputs(Neurone neur) {
        List<Assone> returnList = new ArrayList<>();
        for (int Idx = 0; Idx < AssonList.size(); Idx++) {
            Assone get = AssonList.get(Idx);
            if (get.toNeuron != null) {
                if (get.toNeuron.equals(neur)) {
                    returnList.add(get);
                }
            }
        }
        return returnList;
    }
    
    
    
    
    
    
    private void run_o() {
        // <editor-fold defaultstate="collapsed" desc="Old code"> 
        //int x1[]=topology ;// = {2,3,1};
        //CreateLayerNet(x1);
        //Uti.testsig();
        // thru table or
        //  A|B!C
        //  0|0|0
        //  1|0|1
        //  0|1|0
        //  1|1|1
        //AddNeuron(5);
        //AddInput(2);
        //AddOutput(1);
        //System.out.println("inputList");
        //Uti.PrintAssone(inputList);

        //System.out.println("outputList");
        //Uti.PrintAssone(outputList);
        // </editor-fold >
        MSE mse = new MSE();
        //loop for backprop learning
        ArrayList<double[]> outList = new ArrayList<double[]>();
        for (int i = 0; i < DataList.size(); i++) {
            double[] inArr = DataList.get(i);
            double input_a = inArr[0];
            double input_b = inArr[1];
            double result_c = inArr[2];

            inputList.get(0).value = input_a;
            inputList.get(1).value = input_b;
            //System.out.println("-------Running simulaion--------");

            evaluate();

            double out = outputList.get(0).value;

            mse.add(result_c, out);
            double meanError = Func.meanError(result_c, out);

            //debug prints
            //Uti.printL(new StringBuilder().append("outputList run:").append(i / 3));
            //Uti.printL(new StringBuilder().append("target:").append(result_c).append(" error:").append((String.format("%.2g", meanError))));
            //Uti.PrintAssone(outputList);
            double Ilist[] = {input_a, input_b, result_c, outputList.get(0).value, meanError, mse.evaluate()};
            outList.add(Ilist);
        }
        Uti.printL("----------RESULTS----------");
        Uti.printResults(outList);
    }
    
    private boolean AddInput_o(int quantity) {
        for (int i = 0; i < quantity; i++) {
            AddInput_o();
        }
        return true;

    }

    private boolean AddInput_o() {
        double weight = 1;
        double value = 0;
        for (int i = NeuronList.size() - 1; i > 0; i--) {
            Neurone Neu1 = NeuronList.get(i);
            List<Assone> ins = new ArrayList<>();
            ins = FindInputs(Neu1);
            if (ins.isEmpty()) {
                Assone aszz = new Assone(null, Neu1, weight, value);
                inputList.add(aszz);
                AssonList.add(aszz);
                return true;
            }
            boolean ck = true;
            for (int j = 0; j < ins.size(); j++) {
                Assone ass1 = ins.get(j);
                if (ass1.fromNeuron == null) {
                    ck = false;
                }
            }
            if (ck) {
                Assone aszz = new Assone(null, Neu1, weight, value);
                inputList.add(aszz);
                AssonList.add(aszz);
                return true;
            }
        }
        return false;
    }
    
    
    
    
    
    

    private boolean AddOutput_o(int quantity) {
        for (int i = 0; i < quantity; i++) {
            AddOutput_o();
        }
        return true;

    }

    private boolean AddOutput_o() {
        double weight = 1;
        double value = 0;
        for (int i = 0; i < NeuronList.size(); i++) {
            Neurone Neu1 = NeuronList.get(i);
            List<Assone> ins = new ArrayList<>();
            ins = FindOutputs(Neu1);
            if (ins.isEmpty()) {
                Assone aszz = new Assone(Neu1, null, weight, value);
                outputList.add(aszz);
                AssonList.add(aszz);
                return true;
            }
            boolean ck = true;
            for (int j = 0; j < ins.size(); j++) {
                Assone ass1 = ins.get(j);
                if (ass1.toNeuron == null) {
                    ck = false;
                }
            }
            if (ck) {
                Assone aszz = new Assone(Neu1, null, weight, value);
                outputList.add(aszz);
                AssonList.add(aszz);
                return true;
            }
        }
        return false;
    }

    private void AddNeuron_o() {
        Neurone Nt1 = new Neurone();
        NeuronList.add(Nt1);
        for (int i = 0; i < (NeuronList.size() - 1); i++) {
            Assone assone = new Assone();
            int size = NeuronList.size();
            assone.fromNeuron = NeuronList.get(size - 1);
            assone.toNeuron = NeuronList.get(i);
            AssonList.add(assone);
        }

    }

    private void AddNeuron_o(int nr) {
        for (int i = 0; i < nr; i++) {
            AddNeuron_o();
        }
    }


}
